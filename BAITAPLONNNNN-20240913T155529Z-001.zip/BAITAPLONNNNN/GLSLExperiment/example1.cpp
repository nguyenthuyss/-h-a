﻿/*Chương trình chiếu sáng Blinn-Phong (Phong sua doi) cho hình lập phương đơn vị, điều khiển quay bằng phím x, y, z, X, Y, Z.*/

#include "Angel.h"  /* Angel.h là file tự phát triển (tác giả Prof. Angel), có chứa cả khai báo includes glew và freeglut*/


// remember to prototype
void generateGeometry(void);
void initGPUBuffers(void);
void shaderSetup(void);
void display(void);
void keyboard(unsigned char key, int x, int y);

typedef vec4 point4;
typedef vec4 color4;
using namespace std;

// Số các đỉnh của các tam giác
const int NumPoints = 36;

point4 points[NumPoints]; /* Danh sách các đỉnh của các tam giác cần vẽ*/
color4 colors[NumPoints]; /* Danh sách các màu tương ứng cho các đỉnh trên*/
vec3 normals[NumPoints]; /*Danh sách các vector pháp tuyến ứng với mỗi đỉnh*/

point4 vertices[8]; /* Danh sách 8 đỉnh của hình lập phương*/
color4 vertex_colors[8]; /*Danh sách các màu tương ứng cho 8 đỉnh hình lập phương*/

GLuint program;
GLuint model_loc;
mat4 model;
mat4 instance;
mat4 instance_room;
mat4 projection; // chiếu
GLuint projection_loc;
mat4 view;
GLuint view_loc;
GLfloat mauAnhSang = 1.0;
GLfloat opacity = 1.0; // độ trong suốt 1 là rõ ràng 
float Opacity = 1.0; // độ trong suốt 
GLfloat choisang = 0.2;
GLfloat mauBD = 255;


void initCube()
{
	// Gán giá trị tọa độ vị trí cho các đỉnh của hình lập phương
	vertices[0] = point4(-0.5, -0.5, 0.5, 1.0);
	vertices[1] = point4(-0.5, 0.5, 0.5, 1.0);
	vertices[2] = point4(0.5, 0.5, 0.5, 1.0);
	vertices[3] = point4(0.5, -0.5, 0.5, 1.0);
	vertices[4] = point4(-0.5, -0.5, -0.5, 1.0);
	vertices[5] = point4(-0.5, 0.5, -0.5, 1.0);
	vertices[6] = point4(0.5, 0.5, -0.5, 1.0);
	vertices[7] = point4(0.5, -0.5, -0.5, 1.0);

	// Gán giá trị màu sắc cho các đỉnh của hình lập phương	
	vertex_colors[0] = color4(0.0, 0.0, 0.0, 1.0); // black
	vertex_colors[1] = color4(1.0, 0.0, 0.0, 1.0); // red
	vertex_colors[2] = color4(1.0, 1.0, 0.0, 1.0); // yellow
	vertex_colors[3] = color4(0.0, 1.0, 0.0, 1.0); // green
	vertex_colors[4] = color4(0.0, 0.0, 1.0, 1.0); // blue
	vertex_colors[5] = color4(1.0, 0.0, 1.0, 1.0); // magenta
	vertex_colors[6] = color4(1.0, 0.5, 0.0, 1.0); // orange
	vertex_colors[7] = color4(0.0, 1.0, 1.0, 1.0); // cyan
}
int Index = 0;
void quad(int a, int b, int c, int d)  /*Tạo một mặt hình lập phương = 2 tam giác, gán màu cho mỗi đỉnh tương ứng trong mảng colors*/
{
	vec4 u = vertices[b] - vertices[a];
	vec4 v = vertices[c] - vertices[b];
	vec3 normal = normalize(cross(u, v));

	normals[Index] = normal; colors[Index] = vertex_colors[a]; points[Index] = vertices[a]; Index++;
	normals[Index] = normal; colors[Index] = vertex_colors[a]; points[Index] = vertices[b]; Index++;
	normals[Index] = normal; colors[Index] = vertex_colors[a]; points[Index] = vertices[c]; Index++;
	normals[Index] = normal; colors[Index] = vertex_colors[a]; points[Index] = vertices[a]; Index++;
	normals[Index] = normal; colors[Index] = vertex_colors[a]; points[Index] = vertices[c]; Index++;
	normals[Index] = normal; colors[Index] = vertex_colors[a]; points[Index] = vertices[d]; Index++;
}
void makeColorCube(void)  /* Sinh ra 12 tam giác: 36 đỉnh, 36 màu*/

{
	quad(1, 0, 3, 2);
	quad(2, 3, 7, 6);
	quad(3, 0, 4, 7);
	quad(6, 5, 1, 2);
	quad(4, 5, 6, 7);
	quad(5, 4, 0, 1);
}
void generateGeometry(void)
{
	initCube();
	makeColorCube();
}


void initGPUBuffers(void)
{
	// Tạo một VAO - vertex array object
	GLuint vao;
	glGenVertexArrays(1, &vao);
	glBindVertexArray(vao);

	// Tạo và khởi tạo một buffer object
	GLuint buffer;
	glGenBuffers(1, &buffer);
	glBindBuffer(GL_ARRAY_BUFFER, buffer);
	glBufferData(GL_ARRAY_BUFFER, sizeof(points) + sizeof(colors) + sizeof(normals), NULL, GL_STATIC_DRAW);

	glBufferSubData(GL_ARRAY_BUFFER, 0, sizeof(points), points);
	glBufferSubData(GL_ARRAY_BUFFER, sizeof(points), sizeof(colors), colors);
	glBufferSubData(GL_ARRAY_BUFFER, sizeof(points) + sizeof(colors), sizeof(normals), normals);
}

void shaderSetup(void)
{
	// Nạp các shader và sử dụng chương trình shader
	program = InitShader("vshader1.glsl", "fshader1.glsl");   // hàm InitShader khai báo trong Angel.h
	glUseProgram(program);

	// Khởi tạo thuộc tính vị trí đỉnh từ vertex shader
	GLuint loc_vPosition = glGetAttribLocation(program, "vPosition");
	glEnableVertexAttribArray(loc_vPosition);
	glVertexAttribPointer(loc_vPosition, 4, GL_FLOAT, GL_FALSE, 0, BUFFER_OFFSET(0));

	GLuint loc_vColor = glGetAttribLocation(program, "vColor");
	glEnableVertexAttribArray(loc_vColor);
	glVertexAttribPointer(loc_vColor, 4, GL_FLOAT, GL_FALSE, 0, BUFFER_OFFSET(sizeof(points)));

	GLuint loc_vNormal = glGetAttribLocation(program, "vNormal");
	glEnableVertexAttribArray(loc_vNormal);
	glVertexAttribPointer(loc_vNormal, 3, GL_FLOAT, GL_FALSE, 0, BUFFER_OFFSET(sizeof(points) + sizeof(colors)));

	//color(0, 0, 0);

	model_loc = glGetUniformLocation(program, "Model");// ma trận biến đổi 
	projection_loc = glGetUniformLocation(program, "Projection"); // chieu
	view_loc = glGetUniformLocation(program, "View");// Đây là việc lấy vị trí của biến uniform có tên "View" trong shader program,
														//sử dụng để lưu ma trận nhìn để thực hiện biến đổi từ không gian thế giới sang không gian máy quan sát.

	glEnable(GL_DEPTH_TEST);
	glClearColor(1, 1, 1, 1);        /* Thiết lập màu trắng là màu xóa màn hình*/
}

void mau(GLfloat a, GLfloat b, GLfloat c) {
	/* Khởi tạo các tham số chiếu sáng - tô bóng*/
	point4 light_position(0.0, 2.0, 0.0, 1.0); // vị trí nguồn sáng trong không gian
	color4 light_ambient(0.2, 0.2, 0.2, 1.0); // màu sắc của ánh sáng phản xạ từ mt xung quanh
	color4 light_diffuse(mauAnhSang, mauAnhSang, mauAnhSang, 1.0); // màu sắc của á phản xạ từ nguồn sáng lan tỏa ra mt
	color4 light_specular(choisang, choisang, choisang, 1.0);// màu sắc của ánh sáng phản xạ từ bề mặt vật liệu khi nó được chiếu góc nhìn trực tiếp.

	color4 material_ambient(1.0, 0.0, 1.0, 1.0); // màu sắc của vật liệu trong điều kiện ánh sáng xung quanh.
	color4 material_diffuse(a / 255.0, b / 255.0, c / 255.0, 1.0); //  là màu sắc của vật liệu khi nó được chiếu sáng từ nguồn sáng.
	color4 material_specular(255.0 / 255.0, 255.0 / 255.0, 255 / 255.0, 1.0); //là màu sắc của vật liệu khi nó được chiếu góc nhìn trực tiếp.
	float material_shininess = 100.0;//một số thực đại diện cho độ bóng của vật liệu. Càng cao, bề mặt sẽ trở nên bóng mịn hơn.

	color4 ambient_product = light_ambient * material_ambient;
	color4 diffuse_product = light_diffuse * material_diffuse;
	color4 specular_product = light_specular * material_specular;

	glUniform4fv(glGetUniformLocation(program, "AmbientProduct"), 1, ambient_product);// Cập nhật giá trị của biến uniform "AmbientProduct" trong shader program với giá trị của ambient_product.
	glUniform4fv(glGetUniformLocation(program, "DiffuseProduct"), 1, diffuse_product);
	glUniform4fv(glGetUniformLocation(program, "SpecularProduct"), 1, specular_product);
	glUniform4fv(glGetUniformLocation(program, "LightPosition"), 1, light_position);
	glUniform1f(glGetUniformLocation(program, "Shininess"), material_shininess);
	//glUniform1f(glGetUniformLocation(program, "Opacity"), Opacity);
}


// =============================CỬA RA VÀO==================
GLfloat mo_cua[] = { 0,0 };
mat4 instance_cuavao;
void canh_cua(GLfloat w, GLfloat l, GLfloat h)
{
	instance = Scale(w, h, l);
	glUniformMatrix4fv(model_loc, 1, GL_TRUE,  model * instance_room * instance_cuavao * instance);
	glDrawArrays(GL_TRIANGLES, 0, NumPoints);
}
void tay_nam_cua(GLfloat w, GLfloat l, GLfloat h)
{
	instance = Scale(w, h, l);
	glUniformMatrix4fv(model_loc, 1, GL_TRUE,model * instance_room * instance_cuavao * instance);
	glDrawArrays(GL_TRIANGLES, 0, NumPoints);
}
void bo_cua() {
	instance_cuavao = Identity() * Translate(0, 0, -1) * RotateY(mo_cua[0]) * Translate(0, 0, 0.5); // identy() hàm trả về ma trận đơn vị. khởi tạo 
																									// ma trận cho các phép biến đổi mà k làm thay đổi đối tượng.

	mau(150.0, 75.0, 0.0);// mau nau
	canh_cua(0.04, 1.0, 4.0);

	instance_cuavao = instance_cuavao * Translate(0, 0, 0.35);
	mau(0, 0, 0); // mau den
	tay_nam_cua(0.1, 0.06, 0.5);

	instance_cuavao = Translate(0, 0, 1) * RotateY(mo_cua[1]) * Translate(0, 0, -0.5);
	mau(150.0, 75.0, 0.0); // mau nau
	canh_cua(0.04, 1.0, 4.0);

	instance_cuavao = instance_cuavao * Translate(0, 0, -0.35);
	mau(0, 0, 0);
	tay_nam_cua(0.1, 0.06, 0.5);
}
void cua_build() {
	instance_room = Identity() * Translate(4.5, -0.5, 5.0); // DAT CUA TAI VI TRI
	bo_cua();
}
// ============================TỦ========================== 
mat4 instance_tu;
GLfloat theta1[] = { 0,0,0 };
GLfloat xt;

void than_tu(GLfloat w, GLfloat h, GLfloat l)
{
	instance = Scale(w, h, l);
	glUniformMatrix4fv(model_loc, 1, GL_TRUE,  model * instance_room * instance_tu * instance);
	glDrawArrays(GL_TRIANGLES, 0, NumPoints);
}
void canh_tu(GLfloat w, GLfloat h, GLfloat l)
{
	instance = Scale(w, h, l);
	glUniformMatrix4fv(model_loc, 1, GL_TRUE, model * instance_room * instance_tu * instance);
	glDrawArrays(GL_TRIANGLES, 0, NumPoints);
}

void tu_build()
{
	instance_tu = Identity();
	// hàng 2 cột 3
	instance_tu = Translate(-0.15, 0, 0) * RotateY(theta1[1]) * Translate(0.15, 0, 0); // di chuyển và xoay tủ
	mau(135.0, 206.0, 250.0);
	canh_tu(0.28, 0.48, 0.01); 
	//tay cam
	instance_tu = instance_tu * Translate(0.1, 0, 0);
	mau(0.7, 0.5, 1);
	than_tu(0.02, 0.1, 0.02);
	//mat sau
	instance_tu = Translate(0, 0, 0.295);
	mau(0.3, 0.7, 1); // xanh dương
	than_tu(0.3, 0.5, 0.01);
	//mat trai
	instance_tu = Translate(0.145, 0, 0.145);
	mau(0.3, 0.7, 1);
	than_tu(0.01, 0.5, 0.3);
	//mat phai
	instance_tu = Translate(-0.145, 0, 0.145);
	mau(0.3, 0.7, 1);
	than_tu(0.01, 0.5, 0.3);
	//mat tren
	instance_tu = Translate(0, 0.245, 0.145);
	mau(0.3, 0.7, 1);
	than_tu(0.3, 0.01, 0.3);
	//mat duoi
	instance_tu = Translate(0, -0.245, 0.145);
	mau(0.3, 0.7, 1);
	than_tu(0.3, 0.01, 0.3);

	// hàng 2 cột 4
	instance_tu = Translate(-0.3, 0, 0);
	mau(135.0, 206.0, 250.0);
	canh_tu(0.28, 0.48, 0.01);
	//tay cam
	instance_tu = Translate(-0.2, 0, 0);
	mau(0.7, 0.5, 1);
	than_tu(0.02, 0.1, 0.02);
	//mat sau
	instance_tu = Translate(-0.3, 0, 0.295);
	mau(0.3, 0.7, 1);
	than_tu(0.3, 0.5, 0.01);

	//mat phai
	instance_tu = Translate(-0.4, 0, 0.145);
	mau(0.3, 0.7, 1);
	than_tu(0.01, 0.5, 0.3);
	//mat tren
	instance_tu = Translate(-0.3, 0.245, 0.145);
	mau(0.3, 0.7, 1);
	than_tu(0.3, 0.01, 0.3);
	//mat duoi
	instance_tu = Translate(-0.3, -0.245, 0.145);
	mau(0.3, 0.7, 1);
	than_tu(0.3, 0.01, 0.3);

	// hàng 2 cột 2
	instance_tu = Translate(0.3, 0, 0);
	mau(135.0, 206.0, 250.0);
	canh_tu(0.28, 0.48, 0.01);
	//tay cam
	instance_tu = Translate(0.4, 0, 0);
	mau(0.7, 0.5, 1);
	than_tu(0.02, 0.1, 0.02);;
	//mat sau
	instance_tu = Translate(0.3, 0, 0.295);
	mau(0.3, 0.7, 1);
	than_tu(0.3, 0.5, 0.01);
	//mat trai
	instance_tu = Translate(0.4, 0, 0.145);
	mau(0.3, 0.7, 1);
	than_tu(0.01, 0.5, 0.3);
	//mat tren
	instance_tu = Translate(0.3, 0.245, 0.145);
	mau(0.3, 0.7, 1);
	than_tu(0.3, 0.01, 0.3);
	//mat duoi
	instance_tu = Translate(0.3, -0.245, 0.145);
	mau(0.3, 0.7, 1);
	than_tu(0.3, 0.01, 0.3);

	// hàng 2 cột 1
	instance_tu = Translate(0.45, 0, 0) * RotateY(theta1[1]) * Translate(0.15, 0, 0);
	mau(135.0, 206.0, 250.0);
	canh_tu(0.28, 0.48, 0.01);
	//tay cam
	instance_tu = instance_tu * Translate(0.1, 0, 0);
	mau(0.7, 0.5, 1);
	than_tu(0.02, 0.1, 0.02);
	//mat sau
	instance_tu = Translate(0.6, 0, 0.295);
	mau(0.3, 0.7, 1);
	than_tu(0.3, 0.5, 0.01);
	//mat trai
	instance_tu = Translate(0.7, 0, 0.145);
	mau(0.3, 0.7, 1);
	than_tu(0.01, 0.5, 0.3);

	//mat tren
	instance_tu = Translate(0.6, 0.245, 0.145);
	mau(0.3, 0.7, 1);
	than_tu(0.3, 0.01, 0.3);
	//mat duoi
	instance_tu = Translate(0.6, -0.245, 0.145);
	mau(0.3, 0.7, 1);
	than_tu(0.3, 0.01, 0.3);

	// hàng 3 cột 3
	instance_tu = Translate(0, 0.5, 0);
	mau(135.0, 206.0, 250.0);
	canh_tu(0.28, 0.48, 0.01);
	//tay cam
	instance_tu = Translate(0.1, 0.5, 0);
	mau(0.7, 0.5, 1);
	than_tu(0.02, 0.1, 0.02);
	//mat sau
	instance_tu = Translate(0, 0.5, 0.295);
	mau(0.3, 0.7, 1);
	than_tu(0.3, 0.5, 0.01);
	//mat trai
	instance_tu = Translate(0.145, 0.5, 0.145);
	mau(0.3, 0.7, 1);
	than_tu(0.01, 0.5, 0.3);
	//mat phai
	instance_tu = Translate(-0.145, 0.5, 0.145);
	mau(0.3, 0.7, 1);
	than_tu(0.01, 0.5, 0.3);
	//mat tren
	instance_tu = Translate(0, 0.7, 0.145);
	mau(0.3, 0.7, 1);
	than_tu(0.3, 0.01, 0.3);


	// hàng 3 cột 4
	instance_tu = Translate(-0.45, 0.5, 0) * RotateY(theta1[1]) * Translate(0.15, 0, 0);
	mau(135.0, 206.0, 250.0);
	canh_tu(0.28, 0.48, 0.01);
	//tay cam
	instance_tu = instance_tu * Translate(0.1, 0, 0);
	mau(0.7, 0.5, 1);
	than_tu(0.02, 0.1, 0.02);
	//mat sau
	instance_tu = Translate(-0.3, 0.5, 0.295);
	mau(0.3, 0.7, 1);
	than_tu(0.3, 0.5, 0.01);

	//mat phai
	instance_tu = Translate(-0.4, 0.5, 0.145);
	mau(0.3, 0.7, 1);
	than_tu(0.01, 0.5, 0.3);
	//mat tren
	instance_tu = Translate(-0.3, 0.7, 0.145);
	mau(0.3, 0.7, 1);
	than_tu(0.3, 0.01, 0.3);


	// hàng 3 cột 2
	instance_tu = Translate(0.15, 0.5, 0) * RotateY(theta1[1]) * Translate(0.15, 0, 0);
	mau(135.0, 206.0, 250.0);
	canh_tu(0.28, 0.48, 0.01);
	//tay cam
	instance_tu = instance_tu * Translate(0.1, 0, 0);
	mau(0.7, 0.5, 1);
	than_tu(0.02, 0.1, 0.02);
	//mat sau
	instance_tu = Translate(0.3, 0.5, 0.295);
	mau(0.3, 0.7, 1);
	than_tu(0.3, 0.5, 0.01);
	//mat trai
	instance_tu = Translate(0.4, 0.5, 0.145);
	mau(0.3, 0.7, 1);
	than_tu(0.01, 0.5, 0.3);

	//mat tren
	instance_tu = Translate(0.3, 0.7, 0.145);
	mau(0.3, 0.7, 1);
	than_tu(0.3, 0.01, 0.3);


	// hàng 3 cột 1
	instance_tu = Translate(0.6, 0.5, 0);
	mau(135.0, 206.0, 250.0);
	canh_tu(0.28, 0.48, 0.01);
	//tay cam
	instance_tu = Translate(0.7, 0.5, 0);
	mau(0.7, 0.5, 1);
	than_tu(0.02, 0.1, 0.02);
	//mat sau
	instance_tu = Translate(0.6, 0.5, 0.295);
	mau(0.3, 0.7, 1);
	than_tu(0.3, 0.5, 0.01);
	//mat trai
	instance_tu = Translate(0.7, 0.5, 0.145);
	mau(0.3, 0.7, 1);
	than_tu(0.01, 0.5, 0.3);

	//mat tren
	instance_tu = Translate(0.6, 0.7, 0.145);
	mau(0.3, 0.7, 1);
	than_tu(0.3, 0.01, 0.3);

	// hàng 1 cột 3
	instance_tu = Translate(0, -0.5, 0);
	mau(135.0, 206.0, 250.0);
	canh_tu(0.28, 0.48, 0.01);
	//tay cam
	instance_tu = Translate(0.1, -0.5, 0);
	mau(0.7, 0.5, 1);
	than_tu(0.02, 0.1, 0.02);;
	//mat sau
	instance_tu = Translate(0, -0.5, 0.295);
	mau(0.3, 0.7, 1);
	than_tu(0.3, 0.5, 0.01);
	//mat trai
	instance_tu = Translate(0.145, -0.5, 0.145);
	mau(0.3, 0.7, 1);
	than_tu(0.01, 0.5, 0.3);
	//mat phai
	instance_tu = Translate(-0.145, -0.5, 0.145);
	mau(0.3, 0.7, 1);
	than_tu(0.01, 0.5, 0.3);

	//mat duoi
	instance_tu = Translate(0, -0.7, 0.145);
	mau(0.3, 0.7, 1);
	than_tu(0.3, 0.01, 0.3);

	// hàng 1 cột 4
	instance_tu = Translate(-0.45, -0.5, 0) * RotateY(theta1[1]) * Translate(0.15, 0, 0);
	mau(135.0, 206.0, 250.0);
	canh_tu(0.28, 0.48, 0.01);
	//tay cam
	instance_tu = instance_tu * Translate(0.1, 0, 0);
	mau(0.7, 0.5, 1);
	than_tu(0.02, 0.1, 0.02);
	//mat sau
	instance_tu = Translate(-0.3, -0.5, 0.295);
	mau(0.3, 0.7, 1);
	than_tu(0.3, 0.5, 0.01);

	//mat phai
	instance_tu = Translate(-0.4, -0.5, 0.145);
	mau(0.3, 0.7, 1);
	than_tu(0.01, 0.5, 0.3);

	//mat duoi
	instance_tu = Translate(-0.3, -0.7, 0.145);
	mau(0.3, 0.7, 1);
	than_tu(0.3, 0.01, 0.3);

	// hàng 1 cột 2
	instance_tu = Translate(0.15, -0.5, 0) * RotateY(theta1[1]) * Translate(0.15, 0, 0);
	mau(135.0, 206.0, 250.0);
	canh_tu(0.28, 0.48, 0.01);
	//tay cam
	instance_tu = instance_tu * Translate(0.1, 0, 0);
	mau(0.7, 0.5, 1);
	than_tu(0.02, 0.1, 0.02);
	//mat sau
	instance_tu = Translate(0.3, -0.5, 0.295);
	mau(0.3, 0.7, 1);
	than_tu(0.3, 0.5, 0.01);
	//mat trai
	instance_tu = Translate(0.4, -0.5, 0.145);
	mau(0.3, 0.7, 1);
	than_tu(0.01, 0.5, 0.3);

	//mat duoi
	instance_tu = Translate(0.3, -0.7, 0.145);
	mau(0.3, 0.7, 1);
	than_tu(0.3, 0.01, 0.3);


	// hàng 2 cột 1
	instance_tu = Translate(0.6, -0.5, 0);
	mau(135.0, 206.0, 250.0);
	canh_tu(0.28, 0.48, 0.01);
	//tay cam
	instance_tu = Translate(0.7, -0.5, 0);
	mau(0.7, 0.5, 1);
	than_tu(0.02, 0.1, 0.02);
	//mat sau
	instance_tu = Translate(0.6, -0.5, 0.295);
	mau(0.3, 0.7, 1);
	than_tu(0.3, 0.5, 0.01);
	//mat trai
	instance_tu = Translate(0.7, -0.5, 0.145);
	mau(0.3, 0.7, 1);
	than_tu(0.01, 0.5, 0.3);
	//mat duoi
	instance_tu = Translate(0.6, -0.7, 0.145);
	mau(0.3, 0.7, 1);
	than_tu(0.3, 0.01, 0.3);	
}




GLfloat l = -2.5, r = 2.5;   // giới hạn của khung nhìn
GLfloat bottom = -2.5, top = 2.5;  //giới hạn khung nhìn
GLfloat zNear = 1, zFar = 17; // giới hạn khoảng cách hiển thị được
GLfloat z_eye = -7.0, y_eye = 1; //điểm view x,y
GLfloat x_eye = 0;
GLdouble xx_p, yy_ph, zz_p;


void display(void)
{

	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
	const vec3 viewer_pos(0, y_eye, z_eye);  /*Trùng với eye của camera*/
	model =  RotateY(-60);
	
	tu_build();
	//cua_build();


	vec4 eye(x_eye, y_eye, z_eye, 1);          //điểm nhìn
	vec4 at(0, 0, 0, 1);
	vec4 up(0, 1, 0, 1);
	view = LookAt(eye, at, up);
	glUniformMatrix4fv(view_loc, 1, GL_TRUE, view);

	projection = Frustum(l, r, bottom, top, zNear, zFar);
	glUniformMatrix4fv(projection_loc, 1, GL_TRUE, projection);
	glutSwapBuffers();
}

void reshape(int width, int height)
{

	glViewport(0, 0, width, height);
}
void keyboard(unsigned char key, int x, int y)
{
	// keyboard handler

	switch (key) {
		
	
		//mở đóng cửa ra vào
	case 'c':// mo cua
		mo_cua[0] += 5;
		mo_cua[1] += -5;
		if (mo_cua[0] >= 178) { mo_cua[0] -= (mo_cua[0] - 178); }
		if (mo_cua[1] <= -178) { mo_cua[1] -= (mo_cua[1] + 178); }
		break;
	case 'C'://dong cua
	
		mo_cua[0] -= 5;
		mo_cua[1] -= -5;
		if (mo_cua[0] <0) { mo_cua[0] =0; }
		if (mo_cua[1] >0) { mo_cua[1] =0; }
		break;
	
		//đóng mở cửa tủ
	case 'm': // mo cua tu
		theta1[1] += 5;
		if (theta1[1] > 90) theta1[1] -= 5;
		break;
	case 'M': // dong cua tu
		theta1[1] -= 5;
		if (theta1[1] < 0) theta1[1] += 5;
		break;
	

	case 'z': zNear *= 1.1; zFar *= 1.1; break;
	case 'Z': zNear *= 0.9; zFar *= 0.9; break;// gần xa
	case 'x': x_eye += 0.2; break;// thay đổi vị trí cam theo chiều ngang
	case 'X': x_eye -= 0.2; break;
	case 0:			// 033 is Escape key octal value
		exit(1);		// quit program
		break;
	}

	glutPostRedisplay();
}

int main(int argc, char** argv)
{
	glutInit(&argc, argv);
	glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGBA);
	glutInitWindowSize(1000, 720);
	glutInitWindowPosition(0, 0);
	glutCreateWindow("Phong thuc hanhg");


	glewInit();

	generateGeometry();
	initGPUBuffers();
	shaderSetup();

	glutDisplayFunc(display);
	glutKeyboardFunc(keyboard);
	glutReshapeFunc(reshape);

	//glutPassiveMotionFunc(mouse_callback);

	glutMainLoop();
	return 0;
}
